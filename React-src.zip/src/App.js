import TrainerList from './Trainerlist';
import TraineeList from './Traineelis';
import { BrowserRouter as Router, Route, Link, Routes } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.css';
import { Nav, Navbar, Container, NavDropdown } from 'react-bootstrap';
import Button from 'react-bootstrap/Button'  

function App() {
    return (
        <div>
            <div className='top'>
                <center><h1 className='topheadname'>Relevantz Technologies</h1></center>
            </div>
            <Router>
                <div>
                    <Navbar bg="info" expand="md">
                        <Container>
                            <Navbar.Brand><Button variant="outline-primary">SERVICES</Button></Navbar.Brand>
                            <Navbar.Toggle aria-controls="basic-navbar-nav" />
                            <Navbar.Collapse id="basic-navbar-nav">
                                <Nav className="me-auto">
                                    <Nav.Link href="https://relevantz.com/">Home</Nav.Link>
                                    <Nav.Link href="#link">Link</Nav.Link>
                                    <NavDropdown title="DETAILS" id="basic-nav-dropdown">
                                        <NavDropdown.Item as={Link} to="/Trainerlist">TRAINER DETAILS</NavDropdown.Item>
                                        <NavDropdown.Item  as={Link} to="/TraineElist">TRAINEE DETAILS</NavDropdown.Item>
                                        <NavDropdown.Item href="#action/3.3">MANAGER DETAILS</NavDropdown.Item>
                                        <NavDropdown.Divider />
                                        <NavDropdown.Item href="#action/3.4">ASSESMENT DEATILS</NavDropdown.Item>
                                    </NavDropdown>
                                </Nav>
                            </Navbar.Collapse>
                        </Container>
                    </Navbar>
         <Routes>

                        <Route path="/trainerlist" element={<TrainerList />} />
                        <Route path="/traineelist" element={<TraineeList />} />
                    </Routes>
                </div>
            </Router>
        </div>
    );
}

export default App;

