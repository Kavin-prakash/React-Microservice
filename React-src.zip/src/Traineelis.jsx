import React, { useEffect, useState } from 'react';
import axios from 'axios';

const TraineeList = () => {
    const [Trainee, setTrainees] = useState([]);

    useEffect(() => {
        axios.get('http://localhost:5067/Traineelist')
            .then(response => setTrainees(response.data))
            .catch(error => console.error('Error:', error));
    }, []);

    return (
        <div>
            <h2>Trainee List</h2>
            <ul>
                {Trainee.map(Trainee => (<li key={Trainee.Id}>{Trainee.name},{Trainee.designation},{Trainee.salary}</li>))}
            </ul>
        </div>
    );
};

export default TraineeList;


