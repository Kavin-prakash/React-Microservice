import React, { useEffect, useState } from 'react';
import axios from 'axios';

const TrainerList = () => {
    const [trainers, setTrainers] = useState([]);

    useEffect(() => {
        axios.get('http://localhost:5067/Trainerlist')
            .then(response => setTrainers(response.data))
            .catch(error => console.error('Error:', error));
    }, []);

    return (
        <div>
            <center><h2>Trainer List</h2></center>
            {trainers.length > 0 ? (
                <ul>
                    {trainers.map(trainer => (
                        <li key={trainer.Id}>
                            <strong>Name:</strong> {trainer.name}<br />
                            <strong>Phone Number:</strong> {trainer.phoneNumber}<br />
                            <strong>Designation:</strong> {trainer.designation}
                        </li>
                    ))}
                </ul>
            ) : (
                <p>No trainers found.</p>
            )}
        </div>
    );
};

export default TrainerList;


