using Microsoft.AspNetCore.Mvc;
using Apicrudserver.Data;
using Microsoft.EntityFrameworkCore;
using APICrudServer.Data;
namespace Apicrudserver.Controller

{
    [ApiController]
    [Route("api/[controller]")]

    public class TraineeController : ControllerBase
    {
        private readonly ApiDbContext _context;
        private int id;

        public TraineeController(ApiDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        [Route("GetTrainee")]
        // public async Task<ActionResult<List<Trainee>>> GetTrainee()
        // {
        //     return Ok(await _context.Trainees.ToListAsync());
        // }

        public ActionResult<IEnumerable<Trainee>> Get()
        {
            return _context.Trainees.ToList();
        }


        // [HttpPost]
        // [Route("Create")]

        // public async Task<ActionResult<Trainee>> Create(Trainee trainee)

        // {
        //     _context.Add(trainee);

        //     await _context.SaveChangesAsync();
        //     return Ok(trainee);
        // }

        // [HttpDelete("id")]


        // public async Task<ActionResult> Delete(int id)
        // {
        //     var Trainee = await _context.Trainees.FindAsync(id);

        //     if (Trainee == null)
        //     {
        //         return NotFound("Incorrect Trainee Id");
        //     }


        //     _context.Trainees.Remove(Trainee);
        //     await _context.SaveChangesAsync();

        //     return Ok();
        // }

        // [HttpPut("id")]

        // public async Task<ActionResult<Trainee>> Update(Trainee trainee)
        // {
        //     if (id != trainee.Id)
        //     {

        //         return BadRequest();
        //     }
        //     _context.Entry(trainee).State = EntityState.Modified;
        //     await _context.SaveChangesAsync();
        //     return Ok();

        // }


    }


}

