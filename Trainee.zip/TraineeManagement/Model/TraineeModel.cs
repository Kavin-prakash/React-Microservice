using System.ComponentModel.DataAnnotations;

namespace Apicrudserver.Data
{
    public class Trainee
    {
        [Key]

        public int Id { get; set; }

        [Required] 
        public string? Name { get; set; }

        [Required]

        public string? Desgination { get; set; }


        [Required]

        public long Salary { get; set; }





    }
}