using Microsoft.AspNetCore.Mvc;
using Trainer.Data;
using Microsoft.EntityFrameworkCore;

namespace Trainer.Data
{
    [ApiController]
    [Route("api/[controller]")]
    public class TrainerController : ControllerBase
    {
        private readonly ApiDbContext _context;

        private int id;

        public TrainerController(ApiDbContext context)
        {
            _context = context;
        }
        [HttpGet]
        [Route("GetTrainer")]
         public ActionResult<IEnumerable<Trainer>>Get ()
         {
            return _context.Trainers.ToList();
         }

           // public async Task<ActionResult<int>> GetTrainer(int id)
        // {
        //     return Ok(await _context.Trainers.ToListAsync());
        // }
         

        // [HttpDelete]
        // [Route("id")]

        // public async Task<ActionResult<int>> DeleteTrainer(int id)

        // {
        //     var Trainer = await _context.Trainers.FindAsync(id);


        //     if (Trainer == null)
        //     {
        //         return NotFound("Incorrect Trainee Id");
        //     }


        //     _context.Trainers.Remove(Trainer);
        //     await _context.SaveChangesAsync();

        //     return Ok();
        // }


        // [HttpPut]
        // [Route("id")]

        // public async Task<ActionResult> PutTrainer(Trainer trainer)
        // {
        //     if (id != trainer.Id)
        //     {

        //         return BadRequest();
        //     }
        //     _context.Entry(trainer).State = EntityState.Modified;
        //     await _context.SaveChangesAsync();
        //     return Ok();
        // }


        // [HttpPost]
        // [Route("Create")]

        // public async Task<ActionResult<Trainer>> Create(Trainer trainer)
        // {
        //     _context.Add(trainer);

        //     await _context.SaveChangesAsync();
        //     return Ok();


        // }




    }
}